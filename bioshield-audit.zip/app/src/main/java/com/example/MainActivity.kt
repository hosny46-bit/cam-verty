package com.example

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.ui.theme.MyApplicationTheme
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.MediaType.Companion.toMediaType
import org.json.JSONObject
import kotlin.math.sin

// Futuristic Dark Cyber Colors styled cleanly
val DeepSpaceBg = Color(0xFF03050C)
val ObsidianCard = Color(0xFF0E1220)
val CyberCyan = Color(0xFF00FFCC)
val CyberPurple = Color(0xFF9400D3)
val BrightOrange = Color(0xFFFF5722)
val EcoGreen = Color(0xFF4CAF50)
val SlateGray = Color(0xFF7E8B9B)
val LightAccentBlue = Color(0xFF1E88E5)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme(darkTheme = true) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = DeepSpaceBg
                ) {
                    SimpleStreamPrivacyStudio()
                }
            }
        }
    }
}

// Data model for scenery choice (supporting both procedural & high-quality images)
data class MaskScenery(
    val id: String,
    val titleAr: String,
    val titleEn: String,
    val descAr: String,
    val type: String, // "Sunset", "Forest", "Cosmic", "Stealth", "Image"
    val accentColor: Color,
    val imageUrl: String? = null,
    val isUserUploaded: Boolean = false
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SimpleStreamPrivacyStudio() {
    val context = LocalContext.current

    // Set of Curated High-Quality Nature Images (Unsplash high-fidelity)
    val natureGallery = remember {
        listOf(
            MaskScenery(
                id = "gallery_1",
                titleAr = "شروق الجبال الجليدية 🏔️",
                titleEn = "Ais Mount Sunrise",
                descAr = "منظر لقمم الجبال الجليدية مع انعكاس أشعة الشمس، يمنح بثك فخامة وسكينة.",
                type = "Image",
                accentColor = Color(0xFF81D4FA),
                imageUrl = "https://images.unsplash.com/photo-1454496522488-7a8e488e8606?w=800&auto=format&fit=crop&q=80"
            ),
            MaskScenery(
                id = "gallery_2",
                titleAr = "شاطئ الهدوء الفيروزي 🏖️",
                titleEn = "Turquoise Calm Beach",
                descAr = "رمال ذهبية هادئة مع مياه فيروزية تمنح المشاهدين راحة بصرية فائقة.",
                type = "Image",
                accentColor = Color(0xFF00B0FF),
                imageUrl = "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&auto=format&fit=crop&q=80"
            ),
            MaskScenery(
                id = "gallery_3",
                titleAr = "نور غابة الخيزران 🎋",
                titleEn = "Bamboo Mystic Forest",
                descAr = "أشعة الشمس الذهبية تعبر غابات الخيزران الساحرة لمظهر واثق وثابت.",
                type = "Image",
                accentColor = Color(0xFF66BB6A),
                imageUrl = "https://images.unsplash.com/photo-1502082553048-f009c37129b9?w=800&auto=format&fit=crop&q=80"
            ),
            MaskScenery(
                id = "gallery_4",
                titleAr = "شلالات السكينة الخضراء 🌊",
                titleEn = "Zen Cascading Falls",
                descAr = "شلالات طبيعية مهدئة تعبر بين الصخور الخضراء، تجعل البث يبدو احترافياً.",
                type = "Image",
                accentColor = Color(0xFF4DB6AC),
                imageUrl = "https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05?w=800&auto=format&fit=crop&q=80"
            ),
            MaskScenery(
                id = "gallery_5",
                titleAr = "سديم الكون الأرجواني 🌌",
                titleEn = "Majestic Cosmic Nebula",
                descAr = "ألوان غبار الفضاء المذهلة والنجوم المتلألئة لمنظر خيالي وغامض.",
                type = "Image",
                accentColor = Color(0xFFCE93D8),
                imageUrl = "https://images.unsplash.com/photo-1462331940025-496dfbfc7564?w=800&auto=format&fit=crop&q=80"
            ),
            MaskScenery(
                id = "gallery_6",
                titleAr = "بحيرة الخريف الهادئة 🍁",
                titleEn = "Tranquil Autumn Lake",
                descAr = "سطح مياه صافٍ يعكس أشجار الخريف الزاهية لبعث العمق والتأمل.",
                type = "Image",
                accentColor = Color(0xFFFFB74D),
                imageUrl = "https://images.unsplash.com/photo-1475113548554-5a36f1f523d6?w=800&auto=format&fit=crop&q=80"
            )
        )
    }

    // Procedural canvas animations originally created
    val proceduralSceneries = remember {
        listOf(
            MaskScenery("scene_1", "غروب شمس طبيعي 🌅", "Golden Sunset Nature", "منظر جمالي مهدئ لغروب الشمس فوق سلاسل الجبال لبعث الهدوء والسكينة أثناء التحدث.", "Sunset", BrightOrange),
            MaskScenery("scene_2", "غابات خضراء هادئة 🌲", "Zen Rain Forest", "ألوان الغابة الصامتة مع أوراق الشجر المتحركة لحماية الخصوصية بمظهر طبيعي خلاب.", "Forest", EcoGreen),
            MaskScenery("scene_3", "بحيرة تحت النجوم 🌌", "Cosmic Night Lake", "فضاء كوني ساحر يبعث على التأمل مع تموجات ماء تفاعلية هادئة.", "Cosmic", CyberCyan),
            MaskScenery("scene_4", "أفاتار حجب الهوية 👤", "Stealth Cyber Mask", "أفاتار تقني ذكي وبسيط يتكلم ويتفاعل مع طبقات صوتك الحقيقية.", "Stealth", CyberPurple)
        )
    }

    // Custom Uri-loaded device gallery list
    val customUploadedList = remember { mutableStateListOf<MaskScenery>() }

    var selectedScenery by remember { mutableStateOf<MaskScenery>(natureGallery[0]) }
    var isShieldActive by remember { mutableStateOf(true) }
    var voiceGain by remember { mutableStateOf(0.7f) }
    var voiceAmplitude by remember { mutableStateOf(0.15f) }
    
    // Track selected category tab: 0 -> Curated Nature Gallery, 1 -> Procedural Graphics, 2 -> User Uploads
    var selectedCategoryTab by remember { mutableStateOf(0) }

    // AI Animation Studio State Management
    var aiPromptText by remember { mutableStateOf("") }
    var isAiLoading by remember { mutableStateOf(false) }
    var aiFeedbackMsg by remember { mutableStateOf<String?>(null) }
    var activeAiAnimation by remember {
        mutableStateOf<AIAnimationParams?>(
            AIAnimationParams(
                overlayType = "waterfall",
                speed = 1.1f,
                density = 50,
                directionX = 0f,
                directionY = 1.0f,
                glowColor = "#00FFCC",
                aiExplanation = "تأثير الشلال الافتراضي نشط لتوليد تيار تدفق مائي متجاوب."
            )
        )
    }
    val coroutineScope = rememberCoroutineScope()

    // Modern android system photo picker launcher
    val galleryLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            // Add custom local image to user uploaded list and select it
            val customScene = MaskScenery(
                id = "custom_${System.currentTimeMillis()}",
                titleAr = "صورة من ألبومك 📱",
                titleEn = "Selected Phone Photo",
                descAr = "صورة طبيعية أو مخصصة تم جلبها مباشرة من معرض صور جهازك لتكون بديلاً للكاميرا الحية.",
                type = "Image",
                accentColor = CyberCyan,
                imageUrl = uri.toString(),
                isUserUploaded = true
            )
            customUploadedList.add(0, customScene)
            selectedScenery = customScene
            selectedCategoryTab = 2 // focus to "My Uploads" tab
        }
    }

    // Simulating Microphone Activity waves for reactive animations
    LaunchedEffect(isShieldActive) {
        if (isShieldActive) {
            var tick = 0f
            while (true) {
                delay(50)
                tick += 0.3f
                voiceAmplitude = (0.05f + (Math.abs(sin(tick)) * voiceGain * 0.7f) + (Math.random() * 0.05).toFloat()).coerceIn(0.01f, 0.9f)
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(end = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(
                                text = "مساعد الخصوصية والبث الآمن 🛡️",
                                style = TextStyle(
                                    fontSize = 17.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            )
                            Text(
                                text = "كاميرا افتراضية طبيعية مع تفاعل ذكي لصوتك",
                                style = TextStyle(fontSize = 10.sp, color = CyberCyan)
                            )
                        }
                        // User Badge
                        Text(
                            text = "hosny46@gmail.com",
                            style = TextStyle(
                                fontSize = 11.sp,
                                color = SlateGray,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = ObsidianCard)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(DeepSpaceBg)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            
            // Brief Comforting Introduction Card
            Card(
                colors = CardDefaults.cardColors(containerColor = ObsidianCard),
                border = BorderStroke(1.dp, Color(0xFF1B2335)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.CameraEnhance,
                            contentDescription = "No Face Camera",
                            tint = CyberCyan,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "تم التبسيط: استبدال وجهك بصور طبيعية متفاعلة! 🌿",
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontSize = 14.sp
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "لا تريد الظهور بوجهك؟ حلر نفسك وتحدث بصوتك مباشرة. يعكس هذا البرنامج صورًا هادئة فائقة الجمال أو لوحات تفاعلية بدلاً من كاميرتك المباشرة. عند التحدث بالصوت، تظهر تموجات متجاوبة توضح للمشاهدين أنك تتكلم بأمان تام.",
                        color = SlateGray,
                        fontSize = 12.sp,
                        lineHeight = 18.sp
                    )
                }
            }

            // 1. Live Interactive Video Camera Preview / Scenic Output Shield Window
            Card(
                colors = CardDefaults.cardColors(containerColor = ObsidianCard),
                border = BorderStroke(1.dp, if (isShieldActive) selectedScenery.accentColor else Color(0xFF1E2638)),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(260.dp)
            ) {
                Box(modifier = Modifier.fillMaxSize()) {
                    if (isShieldActive) {
                        // Displaying selected scenery output (either high-quality Unsplash image or procedural layout)
                        if (selectedScenery.type == "Image" && !selectedScenery.imageUrl.isNullOrEmpty()) {
                            AsyncImage(
                                model = ImageRequest.Builder(LocalContext.current)
                                    .data(selectedScenery.imageUrl)
                                    .crossfade(true)
                                    .build(),
                                contentDescription = selectedScenery.titleEn,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                            
                            // Pulse glowing ambient filter on image reacting to voice
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(
                                        Brush.verticalGradient(
                                            colors = listOf(
                                                Color.Transparent,
                                                selectedScenery.accentColor.copy(alpha = voiceAmplitude * 0.3f)
                                            )
                                        )
                                    )
                            )

                            // Render Custom AI Particle Overlay of choice on top of high quality standard images
                            activeAiAnimation?.let { aiAnim ->
                                AIAnimationOverlay(
                                    params = aiAnim,
                                    voiceLevel = voiceAmplitude,
                                    modifier = Modifier.fillMaxSize()
                                )
                            }
                        } else {
                            // Render original beautifully animated procedural canvas
                            DynamicSceneryCanvas(
                                scenery = selectedScenery,
                                voiceLevel = voiceAmplitude,
                                modifier = Modifier.fillMaxSize()
                            )
                        }

                        // Responsive Voice wave overlay directly embedded over the image
                        Canvas(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(80.dp)
                                .align(Alignment.BottomCenter)
                        ) {
                            val w = size.width
                            val h = size.height
                            val wavesPath = Path().apply {
                                moveTo(0f, h / 2f)
                                val steps = 30
                                for (i in 0..steps) {
                                    val x = (w / steps) * i
                                    val sinFactor = sin(i.toFloat() * 0.5f + (voiceAmplitude * 10f))
                                    val y = (h / 2f) + (sinFactor * voiceAmplitude * 30.dp.toPx())
                                    lineTo(x, y)
                                }
                            }
                            drawPath(
                                path = wavesPath,
                                color = selectedScenery.accentColor,
                                style = Stroke(width = 3.dp.toPx())
                            )
                        }

                        // Top indicator stating active privacy projection
                        Box(
                            modifier = Modifier
                                .align(Alignment.TopStart)
                                .padding(12.dp)
                                .clip(RoundedCornerShape(4.dp))
                                .background(Color.Black.copy(alpha = 0.7f))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .clip(CircleShape)
                                        .background(EcoGreen)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    "كاميرا الخصوصية نشطة 🛡️ (وجهك مخفي)",
                                    color = EcoGreen,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        // Top-Right Scenery Name badge
                        Box(
                            modifier = Modifier
                                .align(Alignment.TopEnd)
                                .padding(12.dp)
                                .clip(RoundedCornerShape(4.dp))
                                .background(selectedScenery.accentColor.copy(alpha = 0.85f))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                selectedScenery.titleAr,
                                color = Color.Black,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        // Bottom Voice Visualizer overlay
                        Column(
                            modifier = Modifier
                                .align(Alignment.BottomCenter)
                                .fillMaxWidth()
                                .background(Color.Black.copy(alpha = 0.4f))
                                .padding(8.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.Center,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Mic,
                                    contentDescription = "Voice Active",
                                    tint = selectedScenery.accentColor,
                                    modifier = Modifier.size(12.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    "موجات تفاعل الصوت الذكية نشطة الآن وبدون تقطيع",
                                    color = Color.White.copy(alpha = 0.9f),
                                    fontSize = 10.sp,
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    } else {
                        // Inactive viewport (Camera blacked out completely)
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(Color(0xFF020409))
                                .padding(16.dp),
                            verticalArrangement = Arrangement.Center,
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                imageVector = Icons.Default.VisibilityOff,
                                contentDescription = "Off",
                                tint = BrightOrange,
                                modifier = Modifier.size(44.dp)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                "بث الكاميرا الافتراضية متوقف الآن",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                            Text(
                                "اضغط على زر التشغيل لتشغيل صورة الطبيعة وعكسها للجمهور.",
                                color = SlateGray,
                                fontSize = 11.sp,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
            }

            // Quick Toggle Controls (Play/Pause Privacy projection)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = { isShieldActive = !isShieldActive },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isShieldActive) selectedScenery.accentColor else Color(0xFF223147)
                    ),
                    modifier = Modifier
                        .weight(1.2f)
                        .height(52.dp),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(
                        imageVector = if (isShieldActive) Icons.Default.PauseCircleFilled else Icons.Default.PlayCircleFilled,
                        contentDescription = "Toggle",
                        tint = if (isShieldActive) Color.Black else Color.White
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isShieldActive) "إيقاف حجب الكاميرا مؤقتًا" else "تشغيل حماية الكاميرا والخصوصية",
                        color = if (isShieldActive) Color.Black else Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                // Voice Sensitivity control card
                Card(
                    colors = CardDefaults.cardColors(containerColor = ObsidianCard),
                    border = BorderStroke(1.dp, Color(0xFF1E2638)),
                    modifier = Modifier
                        .weight(0.9f)
                        .height(52.dp),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Icon(
                            imageVector = Icons.Default.VolumeUp,
                            contentDescription = "Gain",
                            tint = selectedScenery.accentColor,
                            modifier = Modifier.size(16.dp)
                        )
                        Column(modifier = Modifier.weight(1f).padding(start = 4.dp)) {
                            Text("حساسية الميكروفون", fontSize = 8.sp, color = SlateGray)
                            Slider(
                                value = voiceGain,
                                onValueChange = { voiceGain = it },
                                colors = SliderDefaults.colors(
                                    thumbColor = selectedScenery.accentColor,
                                    activeTrackColor = selectedScenery.accentColor
                                ),
                                valueRange = 0.1f..1.5f
                            )
                        }
                    }
                }
            }

            // Category Selection Tabs
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(ObsidianCard)
                    .padding(4.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                val tabs = listOf("معرض الصور الطبيعية 🌄", "لوحات تفاعلية 🎨", "ألبوم الموبايل 📱")
                tabs.forEachIndexed { index, title ->
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (selectedCategoryTab == index) selectedScenery.accentColor.copy(alpha = 0.2f) else Color.Transparent)
                            .border(
                                width = 1.dp,
                                color = if (selectedCategoryTab == index) selectedScenery.accentColor else Color.Transparent,
                                shape = RoundedCornerShape(6.dp)
                            )
                            .clickable { selectedCategoryTab = index }
                            .padding(vertical = 10.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = title,
                            color = if (selectedCategoryTab == index) Color.White else SlateGray,
                            fontWeight = if (selectedCategoryTab == index) FontWeight.Bold else FontWeight.Normal,
                            fontSize = 11.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }

            // Displaying current selection items under selected tab
            when (selectedCategoryTab) {
                0 -> {
                    // NATURE PHOTOS GALLERY CATEGORY
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            text = "معرض الصور الطبيعية عالية الجودة (اضغط للاختيار فوراً):",
                            color = Color.White,
                            style = TextStyle(fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        )
                        
                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            items(natureGallery) { scenery ->
                                val isSelected = selectedScenery.id == scenery.id && selectedCategoryTab == 0
                                Card(
                                    colors = CardDefaults.cardColors(
                                        containerColor = if (isSelected) scenery.accentColor.copy(alpha = 0.15f) else ObsidianCard
                                    ),
                                    border = BorderStroke(
                                        width = if (isSelected) 2.dp else 1.dp,
                                        color = if (isSelected) scenery.accentColor else Color(0xFF1E2638)
                                    ),
                                    modifier = Modifier
                                        .width(160.dp)
                                        .clickable { selectedScenery = scenery }
                                ) {
                                    Column {
                                        Box(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .height(95.dp)
                                        ) {
                                            AsyncImage(
                                                model = ImageRequest.Builder(LocalContext.current)
                                                    .data(scenery.imageUrl)
                                                    .crossfade(true)
                                                    .build(),
                                                contentDescription = scenery.titleEn,
                                                contentScale = ContentScale.Crop,
                                                modifier = Modifier.fillMaxSize()
                                            )
                                            if (isSelected) {
                                                Box(
                                                    modifier = Modifier
                                                        .fillMaxSize()
                                                        .background(scenery.accentColor.copy(alpha = 0.3f))
                                                )
                                                Icon(
                                                    imageVector = Icons.Default.CheckCircle,
                                                    contentDescription = "Active",
                                                    tint = Color.White,
                                                    modifier = Modifier
                                                        .align(Alignment.Center)
                                                        .size(24.dp)
                                                )
                                            }
                                        }
                                        Column(modifier = Modifier.padding(8.dp)) {
                                            Text(
                                                scenery.titleAr,
                                                color = Color.White,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 11.sp,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                            Text(
                                                scenery.titleEn,
                                                color = SlateGray,
                                                fontSize = 9.sp,
                                                fontFamily = FontFamily.Monospace,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                1 -> {
                    // PROCEDURAL RENDERS DESIGNS
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            text = "لوحات فنية تفاعلية ومتحركة (تنبض مع مستوى صوتك):",
                            color = Color.White,
                            style = TextStyle(fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        )

                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            items(proceduralSceneries) { scenery ->
                                val isSelected = selectedScenery.id == scenery.id && selectedCategoryTab == 1
                                Card(
                                    colors = CardDefaults.cardColors(
                                        containerColor = if (isSelected) scenery.accentColor.copy(alpha = 0.15f) else ObsidianCard
                                    ),
                                    border = BorderStroke(
                                        width = if (isSelected) 2.dp else 1.dp,
                                        color = if (isSelected) scenery.accentColor else Color(0xFF1E2638)
                                    ),
                                    modifier = Modifier
                                        .width(140.dp)
                                        .clickable { selectedScenery = scenery }
                                ) {
                                    Column(
                                        modifier = Modifier.padding(12.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(45.dp)
                                                .clip(CircleShape)
                                                .background(scenery.accentColor.copy(alpha = 0.2f)),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                imageVector = when (scenery.type) {
                                                    "Sunset" -> Icons.Default.WbSunny
                                                    "Forest" -> Icons.Default.Park
                                                    "Cosmic" -> Icons.Default.FilterHdr
                                                    else -> Icons.Default.Face
                                                },
                                                contentDescription = scenery.titleEn,
                                                tint = scenery.accentColor,
                                                modifier = Modifier.size(22.dp)
                                            )
                                        }
                                        Spacer(modifier = Modifier.height(8.dp))
                                        Text(
                                            scenery.titleAr,
                                            color = Color.White,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 11.sp,
                                            textAlign = TextAlign.Center
                                        )
                                        Text(
                                            scenery.titleEn,
                                            color = SlateGray,
                                            fontSize = 9.sp,
                                            fontFamily = FontFamily.Monospace,
                                            textAlign = TextAlign.Center
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
                2 -> {
                    // USER UPLOADED GALLERY / MOBILE DEVICE STORAGE
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "ألبوم الموبايل متاح (تصفح واختر أي صورة لديك):",
                                color = Color.White,
                                style = TextStyle(fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            )
                            
                            Button(
                                onClick = {
                                    galleryLauncher.launch(
                                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                    )
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = CyberCyan),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                                modifier = Modifier.height(32.dp),
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.PhotoLibrary,
                                    contentDescription = "Pick Image",
                                    tint = Color.Black,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("اختر من المعرض 📱", color = Color.Black, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        if (customUploadedList.isEmpty()) {
                            Card(
                                colors = CardDefaults.cardColors(containerColor = ObsidianCard),
                                border = BorderStroke(1.dp, Color(0xFF1E2638).copy(alpha = 0.5f)),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 12.dp)
                            ) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(24.dp)
                                        .clickable {
                                            galleryLauncher.launch(
                                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                            )
                                        },
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.CloudUpload,
                                        contentDescription = "Upload",
                                        tint = SlateGray,
                                        modifier = Modifier.size(36.dp)
                                    )
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text(
                                        "لا توجد صور مستوردة حاليًا",
                                        color = Color.White,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        "انقر هنا لفتح استوديو الموبايل واختيار صورة طبيعية خاصة بك لتظهر بالبث افتراضياً بدلاً من صورتك.",
                                        color = SlateGray,
                                        fontSize = 10.sp,
                                        lineHeight = 15.sp,
                                        textAlign = TextAlign.Center,
                                        modifier = Modifier.padding(top = 4.dp)
                                    )
                                }
                            }
                        } else {
                            LazyRow(
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                items(customUploadedList) { scenery ->
                                    val isSelected = selectedScenery.id == scenery.id && selectedCategoryTab == 2
                                    Card(
                                        colors = CardDefaults.cardColors(
                                            containerColor = if (isSelected) scenery.accentColor.copy(alpha = 0.15f) else ObsidianCard
                                        ),
                                        border = BorderStroke(
                                            width = if (isSelected) 2.dp else 1.dp,
                                            color = if (isSelected) scenery.accentColor else Color(0xFF1E2638)
                                        ),
                                        modifier = Modifier
                                            .width(140.dp)
                                            .clickable { selectedScenery = scenery }
                                    ) {
                                        Column {
                                            Box(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .height(80.dp)
                                            ) {
                                                AsyncImage(
                                                    model = ImageRequest.Builder(LocalContext.current)
                                                        .data(scenery.imageUrl)
                                                        .crossfade(true)
                                                        .build(),
                                                    contentDescription = scenery.titleEn,
                                                    contentScale = ContentScale.Crop,
                                                    modifier = Modifier.fillMaxSize()
                                                )
                                                if (isSelected) {
                                                    Icon(
                                                        imageVector = Icons.Default.Check,
                                                        contentDescription = "Selected",
                                                        tint = CyberCyan,
                                                        modifier = Modifier
                                                            .align(Alignment.Center)
                                                            .size(24.dp)
                                                    )
                                                }
                                            }
                                            Text(
                                                "صورة مستوردة 📱",
                                                color = Color.White,
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Bold,
                                                modifier = Modifier.padding(8.dp),
                                                textAlign = TextAlign.Center
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Selected item description box
            Card(
                colors = CardDefaults.cardColors(containerColor = ObsidianCard),
                border = BorderStroke(0.5.dp, Color(0xFF1D263B)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = "تفاصيل مظهر كاميرا الخصوصية: ${selectedScenery.titleAr}",
                        color = selectedScenery.accentColor,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = selectedScenery.descAr,
                        color = SlateGray,
                        fontSize = 11.sp,
                        lineHeight = 16.sp
                    )
                }
            }

            // ==========================================
            // AI ANIMATION & PARTICLE PROMPT STUDIO
            // ==========================================
            Card(
                colors = CardDefaults.cardColors(containerColor = ObsidianCard),
                border = BorderStroke(1.dp, selectedScenery.accentColor.copy(alpha = 0.6f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = "AI Animation",
                                tint = CyberCyan,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "مستودع تحريك ملامح الصورة بالذكاء الاصطناعي 🔮 AI",
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                fontSize = 13.sp
                            )
                        }
                        
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(selectedScenery.accentColor.copy(alpha = 0.15f))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "Gemini Flash Active",
                                color = selectedScenery.accentColor,
                                fontSize = 8.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                    
                    Spacer(modifier = Modifier.height(6.dp))
                    
                    Text(
                        text = "اكتب طلبًا مخصصاً لتحريك صورتك الثابتة (مثل: 'حرك الشلال بسرعة ولون فيروزي'، أو 'اجعل السحب تتحرك بلطف ناحية اليمين'، أو 'تساقط ثلج دافئ')، وسيقوم الذكاء الاصطناعي بتحليله وتوليد جزيئات حية متحركة فوق صورتك على الفور!",
                        color = SlateGray,
                        fontSize = 11.sp,
                        lineHeight = 16.sp
                    )
                    
                    Spacer(modifier = Modifier.height(10.dp))
                    
                    // Fast Preset tags for quick click actions in Arabic
                    Text(
                        text = "خيارات تحريك سريعة وجاهزة 👇",
                        color = Color.White.copy(alpha = 0.8f),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    
                    val presets = listOf(
                        "🌊 حرك جريان الشلال" to "حرك جريان الماء والشلال بسرعة تدفق ولون فيروزي مضيء تزامناً مع صوت البث",
                        "☁️ سحب هادئة لليمين" to "اجعل السحب والغيوم تتحرك بلطف شديد لليمين بلون ثلجي ساكن",
                        "🍁 أوراق خريف متساقطة" to "أنشئ هبوب رياح خفيفة تتساقط معها أوراق الأشجار الخريفية الذهبية",
                        "✨ نجوم فلكية مبرقة" to "أضف حقل نجوم بريق كوني تلمع وتنبض طردياً مع مستوى موجة الصوت بصحب شهب خاطفة",
                        "🔥 جمرات دافئة متطايرة" to "أطلق شرارات نار دافئة تتصاعد ببطء وتكبر مع تذبذب الصوت",
                        "❄️ تساقط ثلج قطبي" to "اجعل الثلج يتساقط بهدوء ولطافة تامة على جميع أرجاء المشهد الطبيعي"
                    )
                    
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        items(presets) { (title, promptValue) ->
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(Color(0xFF1E2638).copy(alpha = 0.6f))
                                    .border(0.5.dp, Color(0xFF2C3954), RoundedCornerShape(6.dp))
                                    .clickable { aiPromptText = promptValue }
                                    .padding(horizontal = 8.dp, vertical = 6.dp)
                            ) {
                                Text(text = title, color = Color.White, fontSize = 10.sp)
                            }
                        }
                    }
                    
                    Spacer(modifier = Modifier.height(12.dp))
                    
                    // Input text field with a beautiful Cyan/accent design
                    OutlinedTextField(
                        value = aiPromptText,
                        onValueChange = { aiPromptText = it },
                        placeholder = { Text("مثال: حرك جريان الشلال بلون فيروزي براق وسرعة جيدة...", fontSize = 11.sp, color = SlateGray) },
                        modifier = Modifier.fillMaxWidth().height(56.dp),
                        textStyle = TextStyle(fontSize = 12.sp, color = Color.White),
                        shape = RoundedCornerShape(8.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = selectedScenery.accentColor,
                            unfocusedBorderColor = Color(0xFF1E2638),
                            focusedContainerColor = Color(0xFF070A12),
                            unfocusedContainerColor = Color(0xFF070A12)
                        ),
                        singleLine = true,
                        trailingIcon = {
                            if (aiPromptText.isNotEmpty()) {
                                IconButton(onClick = { aiPromptText = "" }) {
                                    Icon(Icons.Default.Clear, contentDescription = "Clear", tint = SlateGray, modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    )
                    
                    Spacer(modifier = Modifier.height(10.dp))
                    
                    Button(
                        onClick = {
                            if (aiPromptText.isBlank()) return@Button
                            isAiLoading = true
                            aiFeedbackMsg = null
                            coroutineScope.launch {
                                val fallbackName = when (selectedCategoryTab) {
                                    0 -> "معرض الطبيعة"
                                    2 -> "صورة مخصصة"
                                    else -> "لوحة تفاعلية"
                                }
                                val apiKey = try {
                                    BuildConfig.GEMINI_API_KEY
                                } catch (e: Exception) {
                                    ""
                                }
                                
                                val isRealKey = apiKey.isNotEmpty() && apiKeyValid(apiKey)
                                
                                if (isRealKey) {
                                    val result = animateImageWithAI(aiPromptText, fallbackName, apiKey)
                                    if (result != null) {
                                        activeAiAnimation = result
                                        aiFeedbackMsg = "تمت معالجة الحركة بالذكاء الاصطناعي بنجاح! 🚀"
                                    } else {
                                        val localResult = getLocalFallbackParams(aiPromptText)
                                        activeAiAnimation = localResult
                                        aiFeedbackMsg = "ملاحظة: تعذر الاتصال بـ Gemini، تم تشغيل معالج الحركة المحلي فوريًا! ✨"
                                    }
                                } else {
                                    delay(900)
                                    val localResult = getLocalFallbackParams(aiPromptText)
                                    activeAiAnimation = localResult
                                    aiFeedbackMsg = "تم تنشيط معالج الشلال والبيئة محلياً بنجاح! ⚡ (يمكنك إضافة مفتاح Gemini في الإعدادات لتفعيل التحليل الكامل)"
                                }
                                isAiLoading = false
                            }
                        },
                        enabled = !isAiLoading && aiPromptText.isNotBlank(),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = selectedScenery.accentColor,
                            disabledContainerColor = Color(0xFF1E2638)
                        ),
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        if (isAiLoading) {
                            CircularProgressIndicator(modifier = Modifier.size(16.dp), color = Color.Black, strokeWidth = 2.dp)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("جاري معالجة غلاف الحركة الذائبة...", color = Color.Black, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        } else {
                            Icon(Icons.Default.AutoAwesome, contentDescription = "Spark", tint = Color.Black, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("تطبيق حركة الذكاء الاصطناعي ✨", color = Color.Black, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    // Active Feedback explanations
                    activeAiAnimation?.let { animState ->
                        Spacer(modifier = Modifier.height(10.dp))
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF070A11)),
                            border = BorderStroke(0.5.dp, Color(0xFF1E2638)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Analytics, contentDescription = "Stats", tint = selectedScenery.accentColor, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "تقرير تحليل الحركة الافتراضية للذكاء الاصطناعي (AI Telemetry):",
                                        color = selectedScenery.accentColor,
                                        fontSize = 9.sp,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "• نمط التأثير النشط: ${animState.overlayType.uppercase()} | الكثافة: ${animState.density} جزيء مبرمج | السرعة النسبية: ${animState.speed}x",
                                    color = Color.White.copy(alpha = 0.8f),
                                    fontSize = 9.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                                Text(
                                    text = "• متجه الرياح المخطط: (${animState.directionX}, ${animState.directionY}) | لون التوهج اللوني: ${animState.glowColor}",
                                    color = Color.White.copy(alpha = 0.8f),
                                    fontSize = 9.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                                Divider(color = Color(0xFF1E2638).copy(alpha = 0.5f), modifier = Modifier.padding(vertical = 4.dp))
                                Text(
                                    text = "🤖 ${animState.aiExplanation}",
                                    color = CyberCyan,
                                    fontSize = 11.sp,
                                    lineHeight = 16.sp
                                )
                                
                                aiFeedbackMsg?.let { feedback ->
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = feedback,
                                        color = SlateGray,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Interactive helpful step-by-step connection guide
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    "🛠️ كيف أربط صور الطبيعة للبث على اليوتيوب بدون وجهي؟",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
                
                Icon(
                    imageVector = Icons.Default.HelpOutline,
                    contentDescription = "Help Guide",
                    tint = CyberCyan,
                    modifier = Modifier.size(18.dp)
                )
            }

            Card(
                colors = CardDefaults.cardColors(containerColor = ObsidianCard),
                border = BorderStroke(1.dp, Color(0xFF1E273A)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    val stepsAr = listOf(
                        "١. قم بفتح هذا التطبيق واختر صورتك الطبيعية المفضلة من المعرض أو اضغط على 'ألبوم الموبايل' لجلب صورتك الخاصة.",
                        "٢. فعل 'تشغيل حماية الكاميرا والخصوصية' لتلاحظ بدء عرض الصورة مع تموجات صوتك عند التحدث مباشرة من ميكروفون الهاتف.",
                        "٣. قم بتوصيل هاتفك بالكمبيوتر أو افتح اليوتيوب مباشرة من متصفحك. ميزة البث في المتصفحات تسمح لك بمشاركة شاشة الهاتف (Screen Cast / Projection) أو التقاط نافذة التطبيق بواسطة OBS.",
                        "٤. عند تحديد نافذة البرنامج للبث، يتم عرض الصورة الطبيعية التفاعلية مباشرة ويصل صوتك للمستمعين بوضوح، مما يمنع ظهور وجهك نهائياً ويحميك من أي ظهور غير مرغوب فيه بوقار وجمال طبيعي."
                    )
                    stepsAr.forEachIndexed { index, step ->
                        Text(
                            text = step,
                            color = Color.White.copy(alpha = 0.9f),
                            fontSize = 11.sp,
                            lineHeight = 18.sp,
                            modifier = Modifier.padding(vertical = 4.dp)
                        )
                        if (index < stepsAr.size - 1) {
                            Divider(color = Color(0xFF1E2638), modifier = Modifier.padding(vertical = 4.dp))
                        }
                    }
                }
            }

            // Certifications Badge
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Verified, contentDescription = "Security Verified", tint = CyberCyan, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    "تم البث واستبدال الكاميرات محلياً بنسبة 100% حفاظاً على سرية معلوماتك.",
                    fontSize = 10.sp,
                    color = SlateGray,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

// ==========================================
// DYNAMIC PROCEDURAL CANVAS COMPOSABLE AS SECONDARY DESIGNS
// ==========================================
@Composable
fun DynamicSceneryCanvas(
    scenery: MaskScenery,
    voiceLevel: Float, // Amplitude used as custom visual simulation tick
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier) {
        clipRect {
            val width = size.width
            val height = size.height
            val centerX = width / 2f
            val centerY = height / 2f

            when (scenery.type) {
                "Sunset" -> {
                    // Sky gradient
                    drawRect(
                        brush = Brush.verticalGradient(
                            colors = listOf(Color(0xFF2C1B4D), Color(0xFFFF5252), Color(0xFFFF9E00))
                        )
                    )
                    // Sun glowing, growing relative to voice
                    val sunRadius = 45.dp.toPx() + (voiceLevel * 20.dp.toPx())
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(Color(0xFFFFFFB2), Color(0xFFFF9E00).copy(alpha = 0.1f)),
                            center = Offset(centerX, centerY + 20.dp.toPx()),
                            radius = sunRadius
                        ),
                        center = Offset(centerX, centerY + 20.dp.toPx()),
                        radius = sunRadius
                    )
                    // Mountain Silhouette
                    val mountainPath = Path().apply {
                        moveTo(0f, height)
                        lineTo(width * 0.25f, height * 0.55f)
                        lineTo(width * 0.55f, height * 0.72f)
                        lineTo(width * 0.8f, height * 0.48f)
                        lineTo(width, height * 0.65f)
                        lineTo(width, height)
                        close()
                    }
                    drawPath(path = mountainPath, color = Color(0xFF130922))
                    
                    // Waving Water ripples
                    val wavePath = Path().apply {
                        moveTo(0f, height * 0.82f)
                        quadraticTo(
                            width * 0.25f, height * (0.82f + voiceLevel * 0.04f),
                            width * 0.5f, height * 0.82f
                        )
                        quadraticTo(
                            width * 0.75f, height * (0.82f - voiceLevel * 0.04f),
                            width, height * 0.82f
                        )
                    }
                    drawPath(
                        path = wavePath,
                        color = Color(0xFFFFD54F).copy(alpha = 0.4f),
                        style = Stroke(width = 2.dp.toPx())
                    )
                }

                "Forest" -> {
                    // Soft green twilight forest
                    drawRect(
                        brush = Brush.verticalGradient(
                            colors = listOf(Color(0xFF0F201B), Color(0xFF224231))
                        )
                    )
                    // Forest foliage / multiple geometric pine tree contours
                    val treeTops = listOf(
                        Triple(centerX - 90.dp.toPx(), height * 0.8f, 35.dp.toPx()),
                        Triple(centerX + 90.dp.toPx(), height * 0.8f, 40.dp.toPx()),
                        Triple(centerX, height * 0.75f, 50.dp.toPx())
                    )
                    treeTops.forEach { (treeX, treeBottomY, treeWidth) ->
                        val pinePath = Path().apply {
                            moveTo(treeX, treeBottomY - treeWidth * 1.8f) // Tip of pine tree
                            lineTo(treeX + treeWidth, treeBottomY)
                            lineTo(treeX - treeWidth, treeBottomY)
                            close()
                         }
                        drawPath(
                            path = pinePath,
                            color = Color(0xFF0C1914).copy(alpha = 0.9f)
                        )
                        drawPath(
                            path = pinePath,
                            color = EcoGreen.copy(alpha = 0.3f),
                            style = Stroke(width = 1.5.dp.toPx())
                        )
                    }

                    // Simulated fireflies moving with voice level
                    val fireflyCount = 4
                    for (i in 0 until fireflyCount) {
                        val offsetScalarX = sin(voiceLevel * 5f + i) * 60.dp.toPx()
                        val offsetScalarY = sin(voiceLevel * 3f + i * 2f) * 20.dp.toPx()
                        drawCircle(
                            color = Color(0xFFCCFF00),
                            radius = (3.dp.toPx() + (voiceLevel * 4.dp.toPx())),
                            center = Offset(centerX + offsetScalarX - 40.dp.toPx(), centerY + offsetScalarY)
                        )
                    }
                }

                "Cosmic" -> {
                    // Deep dark space blue
                    drawRect(
                        brush = Brush.verticalGradient(
                            colors = listOf(Color(0xFF02040D), Color(0xFF0A122E))
                        )
                    )
                    // Cosmic dust ring shimmering
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(CyberCyan.copy(alpha = 0.25f), Color.Transparent),
                            center = Offset(centerX, centerY),
                            radius = 100.dp.toPx()
                        ),
                        center = Offset(centerX, centerY),
                        radius = 100.dp.toPx()
                    )

                    // Draw multiple cosmic stars of different intensities
                    val stars = listOf(
                        Offset(width * 0.15f, height * 0.25f),
                        Offset(width * 0.85f, height * 0.3f),
                        Offset(width * 0.35f, height * 0.75f),
                        Offset(width * 0.72f, height * 0.65f),
                        Offset(width * 0.5f, height * 0.2f)
                    )
                    stars.forEachIndexed { index, starOffset ->
                        val twinkleFactor = if (index % 2 == 0) voiceLevel else (1f - voiceLevel)
                        drawCircle(
                            color = Color.White.copy(alpha = 0.4f + twinkleFactor * 0.6f),
                            radius = 2.dp.toPx() + (twinkleFactor * 2.1f).dp.toPx(),
                            center = starOffset
                        )
                    }
                }

                else -> {
                    // "Stealth" high tech cyber wireframe shield layout
                    drawRect(color = Color(0xFF070A11))
                    
                    // Cyber concentric circles pulsing
                    val maxRadius = 80.dp.toPx()
                    val pulseRadius = 30.dp.toPx() + (voiceLevel * 50.dp.toPx())
                    drawCircle(
                        color = CyberPurple.copy(alpha = 0.12f),
                        center = Offset(centerX, centerY),
                        radius = maxRadius
                    )
                    drawCircle(
                        color = CyberPurple.copy(alpha = 0.4f),
                        center = Offset(centerX, centerY),
                        radius = pulseRadius,
                        style = Stroke(width = 2.dp.toPx())
                    )

                    // Abstract stealth biometric HUD face indicator
                    val faceWidth = 32.dp.toPx()
                    val faceHeight = 44.dp.toPx()
                    drawOval(
                        color = CyberPurple,
                        topLeft = Offset(centerX - faceWidth / 2f, centerY - faceHeight / 2f),
                        size = Size(faceWidth, faceHeight),
                        style = Stroke(width = 2.dp.toPx())
                    )

                    // Pulse speaking dots
                    drawCircle(
                        color = CyberCyan,
                        radius = 3.dp.toPx() + voiceLevel * 5.dp.toPx(),
                        center = Offset(centerX, centerY + 8.dp.toPx())
                    )
                }
            }
        }
    }
}

// ==========================================
// AI DYNAMIC OVERLAYS & GENERATIVE NETWORKING
// ==========================================

data class AIAnimationParams(
    val overlayType: String, // "waterfall", "clouds", "leaves", "stars", "embers", "snow", "fog"
    val speed: Float,
    val density: Int,
    val directionX: Float,
    val directionY: Float,
    val glowColor: String,
    val aiExplanation: String
)

@Composable
fun AIAnimationOverlay(
    params: AIAnimationParams,
    voiceLevel: Float,
    modifier: Modifier = Modifier
) {
    // Elegant continuous time flow ticket
    val infiniteTransition = rememberInfiniteTransition(label = "ai_tr")
    val timeMs by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1000000f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "time_ticker"
    )

    Canvas(modifier = modifier) {
        clipRect {
            val width = size.width
            val height = size.height

            val particleColor = try {
                Color(android.graphics.Color.parseColor(params.glowColor))
            } catch (e: Exception) {
                CyberCyan
            }

            val densityCount = params.density.coerceIn(10, 150)
            val speedFactor = params.speed.coerceIn(0.1f, 5.0f)

            when (params.overlayType.lowercase()) {
                "waterfall" -> {
                    for (i in 0 until densityCount) {
                        val seedX = (i * 157.3f) % 1f
                        val seedY = (i * 83.1f) % 1f
                        val x = seedX * width
                        val startY = (seedY * height + timeMs * 0.4f * speedFactor) % height
                        val lineLength = 20.dp.toPx() + (voiceLevel * 35.dp.toPx())
                        val strokeW = (1.5f.dp.toPx() + voiceLevel * 2.5f.dp.toPx())

                        drawLine(
                            color = particleColor.copy(alpha = 0.35f + voiceLevel * 0.5f),
                            start = Offset(x, startY),
                            end = Offset(x + params.directionX * 12.dp.toPx(), startY + lineLength),
                            strokeWidth = strokeW
                        )
                    }
                }
                "clouds" -> {
                    for (i in 0 until (densityCount / 12).coerceAtLeast(3)) {
                        val seedX = (i * 193.7f) % 1f
                        val seedY = (i * 57.3f) % 1f
                        val cloudSize = 90.dp.toPx() + (i * 35.dp.toPx())
                        
                        val x = (seedX * width + timeMs * 0.04f * speedFactor * params.directionX) % (width + cloudSize) - cloudSize/2
                        val y = (seedY * height + timeMs * 0.02f * speedFactor * params.directionY) % (height + cloudSize) - cloudSize/2

                        drawCircle(
                            brush = Brush.radialGradient(
                                colors = listOf(particleColor.copy(alpha = 0.12f + voiceLevel * 0.05f), Color.Transparent),
                                center = Offset(x, y),
                                radius = cloudSize
                            ),
                            center = Offset(x, y),
                            radius = cloudSize
                        )
                    }
                }
                "leaves" -> {
                    for (i in 0 until (densityCount / 2)) {
                        val seedX = (i * 223.1f) % 1f
                        val seedY = (i * 71.9f) % 1f
                        val x = (seedX * width + timeMs * 0.06f * speedFactor * params.directionX) % width
                        val y = (seedY * height + timeMs * 0.1f * speedFactor) % height

                        val leafW = 6.dp.toPx()
                        val leafH = 12.dp.toPx() + voiceLevel * 6.dp.toPx()

                        drawOval(
                            color = particleColor.copy(alpha = 0.55f),
                            topLeft = Offset(x, y),
                            size = Size(leafW, leafH)
                        )
                    }
                }
                "stars" -> {
                    for (i in 0 until densityCount) {
                        val seedX = (i * 307.7f) % 1f
                        val seedY = (i * 41.3f) % 1f
                        
                        val pulse = sin(timeMs * 0.005f * speedFactor + i) * 0.5f + 0.5f
                        val rad = 1.dp.toPx() + (pulse * 2.dp.toPx()) + (voiceLevel * 3.dp.toPx())

                        drawCircle(
                            color = particleColor.copy(alpha = 0.25f + pulse * 0.7f),
                            radius = rad,
                            center = Offset(seedX * width, seedY * height)
                        )
                    }
                }
                "embers" -> {
                    for (i in 0 until densityCount) {
                        val seedX = (i * 123.7f) % 1f
                        val seedY = (i * 291.5f) % 1f
                        
                        val sway = sin(timeMs * 0.004f + i) * 12.dp.toPx()
                        val x = (seedX * width + sway + timeMs * 0.04f * speedFactor * params.directionX) % width
                        val upY = (height - (seedY * height + timeMs * 0.12f * speedFactor) % height)
                        val rad = 2.dp.toPx() + (voiceLevel * 4.dp.toPx())

                        drawCircle(
                            color = particleColor.copy(alpha = 0.45f + voiceLevel * 0.5f),
                            radius = rad,
                            center = Offset(x, upY)
                        )
                    }
                }
                "snow" -> {
                    for (i in 0 until densityCount) {
                        val seedX = (i * 211.3f) % 1f
                        val seedY = (i * 143.7f) % 1f
                        
                        val sway = sin(timeMs * 0.003f + i) * 8.dp.toPx()
                        val x = (seedX * width + sway + timeMs * 0.02f * speedFactor * params.directionX) % width
                        val y = (seedY * height + timeMs * 0.06f * speedFactor) % height
                        val rad = 1.5.dp.toPx() + (seedX * 2.5f).dp.toPx() + voiceLevel * 1.5.dp.toPx()

                        drawCircle(
                            color = Color.White.copy(alpha = 0.65f),
                            radius = rad,
                            center = Offset(x, y)
                        )
                    }
                }
                else -> { // Default fog/wind soft bands
                    for (i in 0 until 5) {
                        val seedY = (i * 183.1f) % 1f
                        val fogH = 45.dp.toPx() + (i * 15.dp.toPx())
                        val shift = (timeMs * 0.03f * speedFactor * (1f + i * 0.15f)) % width

                        drawRect(
                            brush = Brush.horizontalGradient(
                                colors = listOf(Color.Transparent, particleColor.copy(alpha = 0.07f), Color.Transparent),
                                startX = shift - width/2,
                                endX = shift + width/2
                            ),
                            topLeft = Offset(0f, seedY * (height - fogH)),
                            size = Size(width, fogH)
                        )
                    }
                }
            }
        }
    }
}

fun apiKeyValid(key: String): Boolean {
    return key.isNotBlank() && key != "MY_GEMINI_API_KEY" && !key.startsWith("placeholder")
}

fun getLocalFallbackParams(prompt: String): AIAnimationParams {
    val lower = prompt.lowercase()
    return when {
        lower.contains("شلال") || lower.contains("ماء") || lower.contains("water") || lower.contains("cascade") -> {
            AIAnimationParams(
                overlayType = "waterfall",
                speed = 1.3f,
                density = 75,
                directionX = 0f,
                directionY = 1.0f,
                glowColor = "#00FFCC",
                aiExplanation = "تم تفعيل محاكي جريان الشلال ذكياً فوريًا لمظهر مائي عذب رائع."
            )
        }
        lower.contains("سحاب") || lower.contains("غيم") || lower.contains("cloud") || lower.contains("wind") || lower.contains("هواء") || lower.contains("نسيم") -> {
            AIAnimationParams(
                overlayType = "clouds",
                speed = 0.75f,
                density = 35,
                directionX = 1.0f,
                directionY = 0.1f,
                glowColor = "#B2EBF2",
                aiExplanation = "تم تمرير رياح هادئة تداعب غيوم وسحب المشهد الجبيل بسلام."
            )
        }
        lower.contains("خريف") || lower.contains("ورق") || lower.contains("شجر") || lower.contains("leaf") || lower.contains("tree") || lower.contains("autumn") -> {
            AIAnimationParams(
                overlayType = "leaves",
                speed = 1.1f,
                density = 45,
                directionX = 0.5f,
                directionY = 1.0f,
                glowColor = "#FFE082",
                aiExplanation = "تم محاكاة تساقط ودوران ورقة نبات ذهبية في نسيم خريفي هادئ."
            )
        }
        lower.contains("نار") || lower.contains("جمر") || lower.contains("لهب") || lower.contains("fire") || lower.contains("ember") || lower.contains("spark") || lower.contains("طبقة") -> {
            AIAnimationParams(
                overlayType = "embers",
                speed = 1.2f,
                density = 55,
                directionX = -0.15f,
                directionY = -1.0f,
                glowColor = "#FF7043",
                aiExplanation = "تم توليد وتصعيد شرر دافئ وجمر برتقالي يتراقص طردياً مع بثك الصوتي."
            )
        }
        lower.contains("ثلج") || lower.contains("جليد") || lower.contains("snow") || lower.contains("ice") || lower.contains("winter") -> {
            AIAnimationParams(
                overlayType = "snow",
                speed = 0.65f,
                density = 80,
                directionX = 0.25f,
                directionY = 1.0f,
                glowColor = "#FFFFFF",
                aiExplanation = "تم تنشيط عاصفة ثلجية لينة ورقيقة تهبط وتسكن فوق الصورة الطبيعية."
            )
        }
        lower.contains("كون") || lower.contains("نجم") || lower.contains("فضاء") || lower.contains("star") || lower.contains("space") || lower.contains("galaxy") || lower.contains("برق") -> {
            AIAnimationParams(
                overlayType = "stars",
                speed = 1.0f,
                density = 85,
                directionX = 0f,
                directionY = 0f,
                glowColor = "#E1BEE7",
                aiExplanation = "تم إشعال طبقة سديم الكون وبوتقة بريق نجوم مجرة سائلة روعة."
            )
        }
        else -> {
            AIAnimationParams(
                overlayType = "fog",
                speed = 0.9f,
                density = 40,
                directionX = 0.4f,
                directionY = 0f,
                glowColor = "#00B0FF",
                aiExplanation = "تم تفعيل حقول السحار الناعم وضباب مائي منسوج كحل ذكي متكيف محلياً."
            )
        }
    }
}

suspend fun animateImageWithAI(
    userPrompt: String,
    imageType: String,
    apiKey: String
): AIAnimationParams? = withContext(Dispatchers.IO) {
    val client = OkHttpClient.Builder()
        .connectTimeout(25, java.util.concurrent.TimeUnit.SECONDS)
        .readTimeout(25, java.util.concurrent.TimeUnit.SECONDS)
        .build()

    val systemPrompt = """
        You are an expert AI Animator for nature photos.
        The user has selected a static photo (Category: $imageType) and wants to animate elements inside it via their prompt.
        Analyze the prompt: '$userPrompt' and return a structured JSON to let our mobile client render beautiful floating particles/flows on top of their photo.
        
        Valid JSON fields to return:
        - "overlayType": string, must be one of: "waterfall", "clouds", "leaves", "stars", "embers", "snow", "fog"
        - "speed": float, must be between 0.3 and 3.5 (speed factor)
        - "density": integer, must be between 15 and 120 (number of particles to render)
        - "directionX": float, must be between -1.0 and 1.0 (horizontal wind drift direction)
        - "directionY": float, must be between -1.0 and 1.0 (vertical drift direction)
        - "glowColor": string, hex hexcode like "#00FFCC", "#CE93D8", "#00B0FF", "#FFE082", or "#FF7043".
        - "aiExplanation": string inside Arabic context, explain how you analyzed '$userPrompt' and set these parameters. Keep it under 22 words.

        Return ONLY a raw JSON block like this, without markdown formatting or surrounding ```json ``` backticks:
        {"overlayType":"waterfall","speed":1.2,"density":65,"directionX":0.0,"directionY":1.0,"glowColor":"#00FFCC","aiExplanation":"أهلاً بك! تم ضبط جريان وتدفق جزيئات الشلال بلون فيروزي ساحر وسرعة مناسبة لطلبك."}
    """.trimIndent()

    val escapedPrompt = userPrompt.replace("\"", "\\\"").replace("\n", " ")
    val escapedSystem = systemPrompt.replace("\"", "\\\"").replace("\n", " ")

    val jsonPayload = """
        {
          "contents": [
            {
              "parts": [
                {
                  "text": "$escapedPrompt"
                }
              ]
            }
          ],
          "generationConfig": {
            "temperature": 0.3,
            "responseMimeType": "application/json"
          },
          "systemInstruction": {
            "parts": [
              {
                "text": "$escapedSystem"
              }
            ]
          }
        }
    """.trimIndent()

    val mediaType = "application/json; charset=utf-8".toMediaType()
    val body = jsonPayload.toRequestBody(mediaType)
    val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=$apiKey"

    val request = Request.Builder()
        .url(url)
        .post(body)
        .build()

    try {
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) return@withContext null
            val responseBody = response.body?.string() ?: return@withContext null
            
            val candidates = JSONObject(responseBody).getJSONArray("candidates")
            val text = candidates.getJSONObject(0)
                .getJSONObject("content")
                .getJSONArray("parts")
                .getJSONObject(0)
                .getString("text")

            val jsonOutput = JSONObject(text.trim())
            AIAnimationParams(
                overlayType = jsonOutput.getString("overlayType"),
                speed = jsonOutput.getDouble("speed").toFloat(),
                density = jsonOutput.getInt("density"),
                directionX = jsonOutput.getDouble("directionX").toFloat(),
                directionY = jsonOutput.getDouble("directionY").toFloat(),
                glowColor = jsonOutput.getString("glowColor"),
                aiExplanation = jsonOutput.getString("aiExplanation")
            )
        }
    } catch (e: Exception) {
        e.printStackTrace()
        null
    }
}
